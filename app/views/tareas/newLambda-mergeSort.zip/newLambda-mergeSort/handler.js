'use strict';
var AWS = require('aws-sdk');
AWS.config.region = 'us-east-1';
var lambda = new AWS.Lambda();
var async = require('async');

module.exports.handler = function(event, context, cb) {

  var nArray = event.array;

  if (nArray.length < 2) {
    context.succeed(nArray);
  }

  var middle = Math.floor(nArray.length / 2),
      arrleft    = nArray.slice(0, middle),
      arrRight   = nArray.slice(middle);

  var params = [{
      FunctionName: 'gmbz-sls-newLambda-mergeSort', // the lambda function we are going to invoke
      InvocationType: 'RequestResponse',
      LogType: 'Tail',
      Payload: '{ "array" : [' + arrleft + '] }'
    },
    {
      FunctionName: 'gmbz-sls-newLambda-mergeSort', // the lambda function we are going to invoke
      InvocationType: 'RequestResponse',
      LogType: 'Tail',
      Payload: '{ "array" : [' + arrRight + '] }'
    }
  ];

  async.parallel({
    left: function(callback){lambda.invoke(params[0], function(err, data) {
    if (err) {
      console.log(err);
      context.fail(err);
    } else {
      callback(null, JSON.parse(data.Payload));
    }
  })},

  right: function(callback){lambda.invoke(params[1], function(err, data) {
    if (err) {
      console.log(err);
      context.fail(err);
    } else {
      callback(null, JSON.parse(data.Payload));
    }
  })}}, function(error, data1){
    if(error){
      console.log(error);
      context.fail(error);
    }
    else{
      var paramsF = {
        FunctionName: 'abbs-sls-newLambda-merge', // the lambda function we are going to invoke
        InvocationType: 'RequestResponse',
        LogType: 'Tail',
        Payload: '{ "arrayLeft" : [' + data1.left + '], "arrayRight" : [' + data1.right + '] }'
      };

      lambda.invoke(paramsF, function(err, data2) {
        if (err) {
          context.fail(err);
        } else {
          cb(null, JSON.parse(data2.Payload));
        }
      });
    }
    });






};
